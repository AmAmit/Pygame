var = 1
while var == 1 : # This constructs an infinite loop
    num = input("Enter a number :")
    print ("You entered: ", num)
print ("Good bye!")
