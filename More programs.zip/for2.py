'''for using list'''
list1=["Sam","Ram","Joseph","Leo","Emma"]
for name in range(len(list1)):
    print(list1[name])
else:
    print ("List is over.")
