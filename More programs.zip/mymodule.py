def hi():
    print("Hi this is my module")
mod=1
