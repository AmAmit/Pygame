for i in range(2,10):
    print(i)
else :
    print("Loop is over.")
