class example:
    print("This is a \'class \'example")
exmp = example
