'''Print a table of 4 using while'''

i=1
while i<11:
    j=4*i
    print("4*",i,"=",j,"\n")
    i+=1
else:
    print("Table complete.")
