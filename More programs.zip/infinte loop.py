exit=0
char=''
while not exit:
    print("Please Get me out of this loop.This is an infinite loop")
    char=input()
print("Thanks")
