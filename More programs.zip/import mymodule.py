import mymodule
mymodule.hi()
print(mymodule.mod)
