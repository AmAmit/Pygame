import sys
import os
print(os.getcwd())
