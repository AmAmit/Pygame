def sum(a,b):
    s=a+b
    return s
summ=sum(8,6)
print(summ)
