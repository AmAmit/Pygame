n=int(input("Enter the value of n till which you want your sum : "))
i=0
summ=0
while i<=n:
    summ+=i
    i+=1
print("Total sum is ",summ)
